---
name: game-research-card-maker
description: Create and maintain English game-design RAG cards in this repository. Use for card research, writing, validation, link repair, digest updates, and DB mirroring.
---

# Game Research Card Maker for Claude

Work only on RAG research-card collection, validation, linking, and DB mirroring. This repository does not own specification writing, Unity implementation, or QA adjudication. Tell the user when a request belongs in another repository.

## Establish repository rules

At the start of the task, locate the repository root and read `AGENTS.md` completely. Claude Code may not load this file automatically, so treat this step as mandatory. Follow its routing table and token limits.

Read only the task-specific source selected by that table:

- Topic scouting: `prompts/0_scout.md`.
- Card research: `prompts/1_researcher.md`.
- Card writing: `prompts/2_writer.md` and exactly one matching template.
- Card validation: `prompts/3_validator.md`.
- Digest update: `prompts/4_updater.md`.
- Link repair: run `scripts/audit_links.py`; read `prompts/5_linker.md` only when a patch is required.
- Existing-card lookup: read `research/_index.md` first, then only the necessary cards within the limit in `AGENTS.md`.
- Multi-card section lookup: use `tools/read_section.py`.
- Similar-card or counterexample search: use `tools/search_cards.py` only after confirming the DB mirror is current.

Do not inspect `db/`, `bridge/`, or `tools/*.py` source unless the task changes the mirror layer itself. Use their command-line interfaces normally.

## Enforce the card contract

Treat Markdown as the source of truth and Postgres as a mirror.

- Write new card titles, summaries, section headings, source markers, interpretation markers, and prose in English.
- Use TOML frontmatter between `+++` delimiters.
- Preserve exact section names and order from `card_schema.py` and the selected template.
- Mark sourced facts and metrics with `[source: publication, as of YYYY-MM]`.
- Put `[interpretation]` before inference, judgment, or synthesis.
- Keep references as exact registered IDs such as `ELEM-021`, `GAME-031`, `GENRE-013`, and `ARCH-015`.
- Never invent an ID. Use `research/_index.md` as the registry.
- Never edit the DB by hand.

Use the matching file in `templates/` as the exact authoring skeleton. Do not copy an existing card as a template.

## Execute the workflow

### Research and write

- Confirm the target's official name, developer or publisher, and release year before collecting evidence.
- Prefer primary and official sources. Use primary documentation for technical claims.
- Attach an as-of date to unstable metrics and preserve conflicting figures.
- Leave evidence gaps explicit; never fabricate a value to fill a section.
- Keep facts and interpretations visibly separate.
- Preserve required empty sections with an HTML evidence-gap comment.
- Set confidence conservatively. Evidence gaps are incompatible with `high` confidence.
- For ARCH cards, read only the relevant section of `reference/unity_project_baseline.md` or `reference/qa_verification_policy.md`.

### Validate

Review the card adversarially, then run the repository validators. In PowerShell:

```powershell
$cards = Get-ChildItem research -Recurse -Filter *.md |
  Where-Object { $_.Name -notlike '_*' } |
  ForEach-Object FullName
python scripts/lint_card.py @cards --index research/_index.md
python scripts/check_sections.py
```

For one card, pass its path directly. Fix every failure before reporting completion.

For translated or migrated cards, compare against Git HEAD:

```powershell
python scripts/migrate_card_lang.py --verify <card-paths>
```

Do not use `--allow-korean-prose` for final validation.

### Audit links

After adding a card, always run:

```powershell
python scripts/audit_links.py --for <CARD-ID>
```

For repository-wide work, run `python scripts/audit_links.py`.

- Close every `확실` finding.
- Inspect each `확인 필요` finding before changing it; it may be intentional.
- Do not invent evidence while repairing a backlink.
- Re-run lint for every card changed by link repair.

### Mirror changes

If a card, card ID, digest, or index-affecting datum changed, run the M-stage in this exact order:

```powershell
python tools/build_index.py
python tools/sync_db.py
python tools/embed_cards.py
python tools/verify_db.py
```

Never run `tools/init_db.py` for mirroring because it drops tables. The default `--transport auto` may fall back from PostgreSQL to the HTTPS bridge. Report the transport used. If DB access fails, report `card complete / mirroring failed` and the reason; do not discard valid Markdown work.

When the mirror is reachable, completion requires `verify_db.py` to report `unresolved_refs: 0`.

### Preserve digest history

Treat existing files in `research/signals/` as append-only. Do not translate or rewrite historical digests during card-language work. Use `prompts/4_updater.md` for digest reflection and preserve its status workflow.

### Handle Git safely

Commit or push only when the user asks or the active repository workflow explicitly requires it.

- Inspect `git status` first and preserve unrelated changes.
- Stage explicit files when unrelated changes exist.
- Follow the repository's recent commit-message style.
- Never force-push or rewrite user history.

## Report completion in Korean

The user-facing report must be written in Korean. Include only applicable results:

- cards created or changed;
- lint and section-check outcome;
- link-audit outcome, separating `확실` from `확인 필요`;
- M-stage outcome and transport;
- unresolved-reference status when available;
- commit or push identifiers only when completed.

Avoid fixed corpus counts, benchmark snapshots, or other volatile metrics unless the user explicitly asks for them.
